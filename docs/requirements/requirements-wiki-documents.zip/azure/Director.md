# McpServer Director (`director`)

`director` is the .NET global tool for administering an MCP Server instance.

It provides:

- CLI commands for health, workspaces, agents, sync, TODOs, and session logs
- OIDC login/logout (`director login`, `whoami`)
- `exec` for running MVVM/CQRS ViewModel commands
- Interactive TUI (`director ui`)

## Command-line parser

`director` references System.CommandLine 2.0.12. Commands use `SetAction` and `ParseResult.GetValue`. The publish guard rejects a System.CommandLine assembly older than 2.0.3, or one that does not declare `SetAction`, so a stale 2.0.0-beta4 DLL cannot be packed again.

`director config` stores defaults in `%USERPROFILE%\.mcpserver\director.config.json`. Set `DIRECTOR_CLI_CONFIG` to use a different file for one process.

## Install

```bash
dotnet tool install --global SharpNinja.McpServer.Director
```

Development/local package install:

```bash
dotnet tool install --global SharpNinja.McpServer.Director --add-source <path-to-nupkg-folder> --ignore-failed-sources
```

## Connecting To MCP Server

### Preferred (workspace marker)

Run `director` inside a workspace that contains `AGENTS-README-FIRST.yaml`, or pass `--workspace <path>`.

The marker provides:

- MCP base URL
- workspace API key
- workspace path context

### Default URL (new system / outside a workspace)

Set a default MCP server URL once:

```bash
director config set-default-url http://localhost:7147
director config show
```

This enables non-workspace commands (for example `health`) when no marker file is present.

Note: workspace/TODO operations still require a workspace marker/API key.

## Common Commands

```bash
director health
director list
director agents defs
director agents ws --workspace E:\github\MyRepo
director sync status
director ui
```

## Auth Commands

```bash
director login
director whoami
director logout
```

## MVVM/CQRS Exec Mode

Discover available ViewModels/aliases:

```bash
director list-viewmodels
director list-viewmodels --filter todo
```

Run a ViewModel command:

```bash
director exec list-todos -i "{\"Section\":\"mvp-mcp\"}"
director exec get-workspace -i "{\"WorkspacePath\":\"E:\\github\\FunWasHad\"}"
```

## Interactive TUI

Launch the Terminal UI:

```bash
director ui
```

Current UI includes role-filtered tabs and auto-refresh on tab entry for supported tabs.

Viewer **Memory** sits immediately after **Sessions**. It surfaces workspace Memory list/get/add/update/remove. Version is display-only (D11); updates do not send `expectedVersion`. There is no Operator Memory role.

Headless lab path (box): `Application.Init(new FakeDriver())`, construct `MemoryScreen`, walk `View.Subviews` for Refresh/Add/Edit/Remove/Filter, then run MCP five-verb awaits after `Application.Shutdown()`. Receipt: `docs/receipts/PLAN-MANAGER-MEMORY-UI-001/lab-smoke-director-box-20260920T001521Z.md`.

## Troubleshooting

- No marker found: set a default URL with `director config set-default-url <url>` or run inside a workspace.
- Permission denied for workspace/policy tabs: re-login and confirm your token has the `admin` role.
- Expired token: run `director login` again.

## Repository

- Source: <https://github.com/sharpninja/McpServer>
